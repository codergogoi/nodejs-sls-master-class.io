export const BASE_URL = "http://localhost:4000"; // Your local customer service URL
export const PRODUCT_URL = "http://localhost:3000"; // Your local customer service URL
export const TRANSACTION_URL =
  "https://4favyg1qn0.execute-api.eu-central-1.amazonaws.com/prod";

export const S3URL = process.env.REACT_APP_S3_URL;
