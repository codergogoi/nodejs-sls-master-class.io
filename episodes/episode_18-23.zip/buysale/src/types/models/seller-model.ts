export interface SellerProductModel {
  token: string;
  _id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  createdAt: string;
  userType: string;
}
