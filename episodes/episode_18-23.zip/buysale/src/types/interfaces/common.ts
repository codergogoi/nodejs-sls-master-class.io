export interface ResponseModel {
  msg: string;
  data?: any;
}
