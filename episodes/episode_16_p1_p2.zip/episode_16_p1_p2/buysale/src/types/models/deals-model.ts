export interface DealsModel {
  name: string;
  description: string;
  img: string;
}
