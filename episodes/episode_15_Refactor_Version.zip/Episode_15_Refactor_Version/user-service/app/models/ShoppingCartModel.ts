export interface ShoppingCartModel {
  cart_id: number;
  user_id: number;
}
