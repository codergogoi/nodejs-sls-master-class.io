import { Client } from "pg";

export const DBClient = () => {
  return new Client({
    host: "ec2-3-71-35-109.eu-central-1.compute.amazonaws.com",
    user: "user_service",
    database: "user_service",
    password: "user_service#2023",
    port: 5432,
  });
};

/*
self managed  host: "ec2-3-71-187-16.eu-central-1.compute.amazonaws.com", 
aws managed host: "user-service.cayrxletla8g.eu-central-1.rds.amazonaws.com",
    user: "user_service",
    database: "user_service",
    password: "user_service#2023",
    port: 5432,
*/
