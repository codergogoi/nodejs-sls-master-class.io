ALTER TABLE IF EXISTS "address" DROP CONSTRAINT IF EXISTS "address_user_id_fkey";

DROP TABLE "address";