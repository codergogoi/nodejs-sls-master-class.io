ALTER TABLE users
DROP COLUMN stripe_id,
DROP COLUMN payment_id;