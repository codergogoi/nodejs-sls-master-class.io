export interface OrderModel {
  id: string;
  user_id: number;
  status: string;
  amount: number;
  transaction_id: number;
  order_ref_id: number;
}
