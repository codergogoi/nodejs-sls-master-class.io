export interface UserInput {}
