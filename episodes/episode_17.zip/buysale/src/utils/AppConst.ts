export const BASE_URL =
  "https://i9zuzpsxp2.execute-api.eu-central-1.amazonaws.com"; //"http://localhost:4000"; // Your local customer service URL
export const TRANSACTION_URL =
  "https://4favyg1qn0.execute-api.eu-central-1.amazonaws.com/prod";
